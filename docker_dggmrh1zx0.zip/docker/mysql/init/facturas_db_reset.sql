DELETE FROM totales_factura;
ALTER TABLE totales_factura AUTO_INCREMENT=1;

DELETE FROM detalle_factura;
ALTER TABLE detalle_factura AUTO_INCREMENT=1;

DELETE FROM descuentos_recargos_factura;
ALTER TABLE descuentos_recargos_factura AUTO_INCREMENT=1;

DELETE FROM rango_numeracion;
ALTER TABLE rango_numeracion AUTO_INCREMENT=1;

DELETE FROM cabecera_factura;
ALTER TABLE cabecera_factura AUTO_INCREMENT=1;

DELETE FROM cabecera_factura;
ALTER TABLE cabecera_factura AUTO_INCREMENT=1;

DELETE FROM factura;
ALTER TABLE factura AUTO_INCREMENT=1;
